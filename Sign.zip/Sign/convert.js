/*
make an array full of different words
make an array full of fingerspelling signs
then use a for loop to check for each letter, add the fingerspelling version to a new array
display that array

*/

var words = new Array();
words[0] = "Hello";
words[1] = "Good-Bye";
words[2] = "Welcome";
words[3] = "Please";
words[4] = "Thank You";
words[5] = "Excuse Me";
words[6] = "Sorry";
words[7] = "Take Care"
words[8] = "Hearing";
words[9] = "Deaf";
words[10] = "I Love You";
words[11] = "Friend";
words[12] = "Pretty";
words[13] = "Yes";
words[14] = "No";
words[15] = "Maybe";
words[16] = "Who";
words[17] = "What";
words[18] = "When";
words[19] = "Where";
words[20] = "Why";
words[21] = "How";
words[22] = "w";
words[23] = "x";
words[24] = "y";
words[25] = "z";

var imgs = new Array();
imgs[0] = "signfs/a";
imgs[1] = "signfs/b";
imgs[2] = "signfs/c";
imgs[3] = "signfs/d";
imgs[4] = "signfs/e";
imgs[5] = "signfs/f";
imgs[6] = "signfs/g";
imgs[7] = "signfs/h"
imgs[8] = "signfs/i";
imgs[9] = "signfs/j";
imgs[10] = "signfs/k";
imgs[11] = "signfs/l";
imgs[12] = "signfs/m";
imgs[13] = "signfs/n";
imgs[14] = "signfs/o";
imgs[15] = "signfs/p";
imgs[16] = "signfs/q";
imgs[17] = "signfs/r";
imgs[18] = "signfs/s";
imgs[19] = "signfs/t";
imgs[20] = "signfs/u";
imgs[21] = "signfs/v";
imgs[22] = "signfs/w";
imgs[23] = "signfs/x";
imgs[24] = "signfs/y";
imgs[25] = "signfs/z";

function randomize(){
	let thisWord = Math.floor(Math.random()*words.length);
	let output = words[thisWord];
	
	document.getElementById("result").innerHTML = output;
	document.getElementById("result2").src = imgs[thisWord];
}

/* FOR FINGERSPELLING

var imgs = new Array();
imgs[0] = "signfs/a";
imgs[1] = "signfs/b";
imgs[2] = "signfs/c";
imgs[3] = "signfs/d";
imgs[4] = "signfs/e";
imgs[5] = "signfs/f";
imgs[6] = "signfs/g";
imgs[7] = "signfs/h"
imgs[8] = "signfs/i";
imgs[9] = "signfs/j";
imgs[10] = "signfs/k";
imgs[11] = "signfs/l";
imgs[12] = "signfs/m";
imgs[13] = "signfs/n";
imgs[14] = "signfs/o";
imgs[15] = "signfs/p";
imgs[16] = "signfs/q";
imgs[17] = "signfs/r";
imgs[18] = "signfs/s";
imgs[19] = "signfs/t";
imgs[20] = "signfs/u";
imgs[21] = "signfs/v";
imgs[22] = "signfs/w";
imgs[23] = "signfs/x";
imgs[24] = "signfs/y";
imgs[25] = "signfs/z";

function randomize(){
	let thisWord = Math.floor(Math.random()*words.length);
	output = words[thisWord];
	
	document.getElementById("result").innerHTML = output;
	
	for(let i=0; i<output.length; i++){
		
		imgs[i] = "signfs/a";
		}
		
	}
}

*/

/*
var x = randomize();

function display(){
	document.getElementById("result").innerHTML = x; //TBD. Just for checking if randomize worked.
}


/*
var x = randomize();

function display(){
	document.getElementById("result2").innerHTML = x; //TBD. Just for checking if randomize worked.
	document.getElementById("result").src = x;
    document.getElementById("fate").src = x;
	// inspiration for .src from this: https://stackoverflow.com/questions/767143/variable-for-img-src
	
	document.getElementById("tarotButton1").onclick = null;
	document.getElementById("tarotButton2").onclick = null;
	document.getElementById("tarotButton3").onclick = null;
	document.getElementById("tarotButton4").onclick = null;
	document.getElementById("tarotButton5").onclick = null;
	document.getElementById("tarotButton6").onclick = null;

	/*code for button only being pressed once:
		https://stackoverflow.com/questions/32469366/javascript-button-pressed-only-once>
		It was used to get the ".onclick=null" parts of the code, to prevent display from being run again.
	
}

function t1(){
	document.getElementById("tarot1").id = "result";
	display();
	
	/*The .id came from myself figuring out that if .src changed the src then .id could change the id
		Therefore I thought I would put different if statements to make a certain one 
		the one that would change images depending on which one was pressed. 
}
function t2(){
	document.getElementById("tarot2").id = "result";
	display();
}
function t3(){
	document.getElementById("tarot3").id = "result";
	display();
}
function t4(){
	document.getElementById("tarot4").id = "result";
	display();
}
function t5(){
	document.getElementById("tarot5").id = "result";
	display();
}
function t6(){
	document.getElementById("tarot6").id = "result";
	display();
}



/*
var aValue = 0;

aValue = parseInt(localStorage.getItem("myValue"));
showA();

function showA()
{
	document.getElementById("aVal").innerHTML = "A = " + aValue;
}

function reset()
{
	aValue = 0;
	showA();
}

function addToValue(number)
{
	aValue += number;
	showA();
}

function goToNextPage(nextPage)
{
	localStorage.setItem("myValue", aValue)
	window.location.href = nextPage;
	location.replace(nextPage);
}
*/

//Can look at localstorage later to get inspiration on how to save certain values over multiple pages
