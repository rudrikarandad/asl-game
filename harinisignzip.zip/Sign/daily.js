var daily = new Array();
daily[0] = "Hello";
daily[1] = "Good-Bye";
daily[2] = "Welcome";
daily[3] = "Please";
daily[4] = "Thank You";
daily[5] = "Excuse Me";
daily[6] = "Sorry";
daily[7] = "Take Care"
daily[8] = "Hearing";
daily[9] = "Deaf";
daily[10] = "Blind";
daily[11] = "I Love You";
daily[12] = "Yes";
daily[13] = "No";
daily[14] = "Maybe";
daily[15] = "Finger Spelling";
daily[16] = "Sign";
daily[17] = "Sick";
daily[18] = "Pain";
daily[19] = "Highschool";
daily[20] = "Middleschool";
daily[21] = "Elementary";

/*
words[11] = "Friend";
words[12] = "Mother";
words[13] = "Father";
words[17] = "Who";
words[18] = "Where";
words[19] = "Why";
words[20] = "How";
words[21] = "Someone/Something";
words[22] = "Here";
words[23] = "There";
words[24] = "Nothing";
words[25] = "My";
words[26] = "Your";
words[27] = "Us";
words[28] = "Those";
words[32] = "From";
words[33] = "And";
words[34] = "But";
words[35] = "Because";*/

//fun fact there is no sign for "is" in sign language

var imgs = new Array();
imgs[0] = "signfs/a";
imgs[1] = "signfs/b";
imgs[2] = "signfs/c";
imgs[3] = "signfs/d";
imgs[4] = "signfs/e";
imgs[5] = "signfs/f";
imgs[6] = "signfs/g";
imgs[7] = "signfs/h"
imgs[8] = "signfs/i";
imgs[9] = "signfs/j";
imgs[10] = "signfs/k";
imgs[11] = "signfs/l";
imgs[12] = "signfs/m";
imgs[13] = "signfs/n";
imgs[14] = "signfs/o";
imgs[15] = "signfs/p";
imgs[16] = "signfs/q";
imgs[17] = "signfs/r";
imgs[18] = "signfs/s";
imgs[19] = "signfs/t";
imgs[20] = "signfs/u";
imgs[21] = "signfs/v";

let output = "";

function randomize(){
	let thisWord = Math.floor(Math.random()*daily.length);
	output = daily[thisWord];
	//save that value to be compared for checking later. its the index;
	
	document.getElementById("result").innerHTML = output;
	document.getElementById("result2").src = imgs[thisWord];
}

function check(){
	let index = 0;
	let input = prompt("Enter what word you think the displayed sign is");
	//checks the word array to see which index it is
	for(let i=0; i<daily.length; i++){
		if(input == daily[i]){
			index = i;
		}
	}//makes sure the word that was inputted (aka index) is the actual sign (randomized img index)
	if(daily[index].toLowerCase==output.toLowerCase){
		document.getElementById("torf").innerHTML = "CORRECT";
	}
	else{
		document.getElementById("torf").innerHTML = "INCORRECT";
	}
}