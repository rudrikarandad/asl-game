var daily = new Array();
daily[0] = "Hello";
daily[1] = "Goodbye";
daily[2] = "Welcome";
daily[3] = "Please";
daily[4] = "Thank You";
daily[5] = "Excuse Me";
daily[6] = "Sorry";
daily[7] = "Take Care"
daily[8] = "Hearing";
daily[9] = "Deaf";
daily[10] = "Blind";
daily[11] = "I Love You";
daily[12] = "Yes";
daily[13] = "No";
daily[14] = "Maybe";
daily[15] = "Finger Spelling";
daily[16] = "Sign";
daily[17] = "Sick";
daily[18] = "Pain";
daily[19] = "Highschool";
daily[20] = "College";

var grammar = new Array();
grammar[0] = "Right";
grammar[1] = "Left";
grammar[2] = "North";
grammar[3] = "South";
grammar[4] = "East";
grammar[5] = "West"
grammar[6] = "Down";
grammar[7] = "Up";
grammar[8] = "Near";
grammar[9] = "Far";
grammar[10] = "Myself";
grammar[11] = "My";
grammar[12] = "You";
grammar[13] = "We";
grammar[14] = "Us";
grammar[15] = "Our";
grammar[16] = "Those";
grammar[17] = "Your";
grammar[18] = "Yours, theirs, hers, his";
grammar[19] = "Someone, something";
grammar[20] = "Thing";
grammar[21] = "Nothing";
grammar[22] = "Here";
grammar[23] = "There";
grammar[24] = "In";
grammar[25] = "Out";
grammar[26] = "Behind";
grammar[27] = "Between";
grammar[28] = "Below";
grammar[29] = "From";
grammar[30] = "And";
grammar[31] = "But";
grammar[32] = "Because";

var desc = new Array();
desc[0] = "Pretty";
desc[1] = "Ugly";
desc[2] = "Smart";
desc[3] = "Large";
desc[4] = "Small";
desc[5] = "Tall";
desc[6] = "Short";
desc[7] = "Thin"
desc[8] = "Fat";
desc[9] = "Polite";
desc[10] = "Kind";
desc[11] = "Lazy";
desc[12] = "Funny";
desc[13] = "Friendly";
desc[14] = "Proud";
desc[15] = "Tired";
desc[16] = "Lonely";
desc[17] = "Surprised";
desc[18] = "Angry";
desc[19] = "Happy";
desc[20] = "Sad";

//fun fact there is no sign for "is" in sign language

var imgs = new Array();
imgs[0] = "signfs/a";
imgs[1] = "signfs/b";
imgs[2] = "signfs/c";
imgs[3] = "signfs/d";
imgs[4] = "signfs/e";
imgs[5] = "signfs/f";
imgs[6] = "signfs/g";
imgs[7] = "signfs/h"
imgs[8] = "signfs/i";
imgs[9] = "signfs/j";
imgs[10] = "signfs/k";
imgs[11] = "signfs/l";
imgs[12] = "signfs/m";
imgs[13] = "signfs/n";
imgs[14] = "signfs/o";
imgs[15] = "signfs/p";
imgs[16] = "signfs/q";
imgs[17] = "signfs/r";
imgs[18] = "signfs/s";
imgs[19] = "signfs/t";
imgs[20] = "signfs/u";
imgs[21] = "signfs/v";

let output = "";

function randomize(){
	let thisWord = Math.floor(Math.random()*daily.length);
	output = daily[thisWord];
	//save that value to be compared for checking later. its the index;
	
	document.getElementById("result").innerHTML = output;
	document.getElementById("result2").src = imgs[thisWord];
}

function check(){
	let index = 0;
	let input = prompt("Enter what word you think the displayed sign is");
	//checks the word array to see which index it is
	for(let i=0; i<daily.length; i++){
		if(input == daily[i]){
			index = i;
		}
	}//makes sure the word that was inputted (aka index) is the actual sign (randomized img index)
	if((daily[index]).toLowerCase==output){
		document.getElementById("torf").innerHTML = "CORRECT";
	}
	else{
		document.getElementById("torf").innerHTML = "INCORRECT";
	}
}